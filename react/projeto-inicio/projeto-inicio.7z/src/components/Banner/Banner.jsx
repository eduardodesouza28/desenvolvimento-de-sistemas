import './Banner.css';

function Banner() {
  return (
    <div class="banner">
      <img src="/assets/banner_desi.png" alt="banner" />
    </div>
  );
}

export default Banner;